<?php
$passkey="nep_key";
?>