<?php
rename("index.php","./Zdumpped/index.old");
rename("db_name.php","./Zdumpped/db_name.old");
rename("create.php","./Zdumpped/create.old");
rename("set.php","index.php");
header("Location:./");
?>