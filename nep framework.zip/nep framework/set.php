<?php
echo("Do assess controller through /Router");

?>